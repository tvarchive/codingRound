import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HotelBookingTest {
	
	@FindBy(linkText = "Hotels")
    private static WebElement hotelLink;

    @FindBy(id = "Tags")
    private static WebElement localityTextBox;

    @FindBy(id = "SearchHotelsButton")
    private static WebElement searchButton;

    @FindBy(id = "travellersOnhome")
    private static WebElement travellerSelection;
    
    public static void hotelLink()
    {
    	hotelLink.click();
    }
    
    public static void locality()
    {
    	localityTextBox.sendKeys("Indiranagar, Bangalore"); 
    }
    
    public static void SearchHotel()
    {
    	searchButton.click();
    }
    public static void travellersHome()
    {
    	travellerSelection.click();
    }

}

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

import com.sun.javafx.PlatformUtil;

public class BaseClass
{
	WebDriver driver = new ChromeDriver();
	
	
	@BeforeTest
	
	private void setDriverPath()
    {
        if (PlatformUtil.isMac()) 
        {
            System.setProperty("webdriver.chrome.driver", "chromedriver");
        }
        if (PlatformUtil.isWindows()) 
        {
            System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        }
        if (PlatformUtil.isLinux()) 
        {
            System.setProperty("webdriver.chrome.driver", "chromedriver_linux");
        }
    }
	
}

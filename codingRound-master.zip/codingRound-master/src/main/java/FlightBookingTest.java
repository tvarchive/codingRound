import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FlightBookingTest 
{
	@FindBy(id = "Oneway")
    private static WebElement Oneway;

    @FindBy(id = "FromTag")
    private static WebElement FromTag;

    @FindBy(id = "toTag")
    private static WebElement toTag;
    
    @FindBy(id = "SearchBtn")
    private static WebElement SearchBtn;
    
    public void Oneway()
    {
    	Oneway.click();
    }
    public void FromTag()
    {
    	FromTag.clear();
        FromTag.sendKeys("Bangalore");
    }
    public void toTag()
    {
    	toTag.clear();
    	toTag.sendKeys("Delhi");
    }
    public void SearchBtn()
    {
    	SearchBtn.click();
    }

}
